package contact;
/*
Jason Carignan
CS-320 Software Test, Automation QA
Professor Toledo
March 18, 2025
 */
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    // Add contact (Must be unique and not updatable)
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Duplicate ID found. Contact ID must be unique.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete contact by Contact ID
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.remove(contactId);
    }

    // Update contact fields - First Name, Last Name, Phone, Address
    public void updateFirstName(String contactId, String newFirstName) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.get(contactId).setFirstName(newFirstName);
    }

    public void updateLastName(String contactId, String newLastName) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.get(contactId).setLastName(newLastName);
    }

    public void updatePhone(String contactId, String newPhone) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.get(contactId).setPhone(newPhone);
    }

    public void updateAddress(String contactId, String newAddress) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.get(contactId).setAddress(newAddress);
    }

    // Retrieve contact
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}

