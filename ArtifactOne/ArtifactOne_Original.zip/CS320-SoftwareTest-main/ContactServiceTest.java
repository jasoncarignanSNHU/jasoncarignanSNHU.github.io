package contact;
/*
Jason Carignan
CS-320 Software Test, Automation QA
Professor Toledo
March 18, 2025
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    void testAddContact() {
        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    void testAddDuplicateContact() {
        Contact duplicateContact = new Contact("12345", "Jane", "Doe", "0987654321", "456 Elm St");
        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicateContact));
    }

    @Test
    void testDeleteContact() {
        service.deleteContact("12345");
        assertNull(service.getContact("12345"));
    }

    @Test
    void testUpdateFirstName() {
        service.updateFirstName("12345", "Jane");
        assertEquals("Jane", service.getContact("12345").getFirstName());
    }

    @Test
    void testUpdatePhoneInvalid() {
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("12345", "123"));
    }
}
