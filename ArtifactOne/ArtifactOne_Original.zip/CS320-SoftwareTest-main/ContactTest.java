package contact;
/*
Jason Carignan
CS-320 Software Test, Automation QA
Professor Toledo
March 18, 2025
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    //Test Creating a new contact with proper params
    void testValidContactCreation() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // Test invalid contact ID cases - null or too long
    @Test
    void testInvalidContactId_Null() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    void testInvalidContactId_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678910", "John", "Doe", "1234567890", "123 Main St"));
    }

    // Test invalid first name cases - null or too long
    @Test
    void testInvalidFirstName_Null() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", null, "Doe", "1234567890", "123 Main St"));
    }

    @Test
    void testInvalidFirstName_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "12345678910", "Doe", "1234567890", "123 Main St"));
    }

    // Test invalid last name cases - null or too long
    @Test
    void testInvalidLastName_Null() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", null, "1234567890", "123 Main St"));
    }

    @Test
    void testInvalidLastName_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "LongLastName10", "1234567890", "123 Main St"));
    }

    // Test invalid phone cases - Null/too long/too short/non-numeric
    @Test
    void testInvalidPhone_Null() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", null, "123 Main St"));
    }

    @Test
    void testInvalidPhone_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234567891011", "123 Main St"));
    }
    
    @Test
    void testInvalidPhone_TooShort() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234", "123 Main St"));
    }
    @Test
    void testInvalidPhone_NonNumeric() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "abcdefghij", "123 Main St"));
    }

    // Test invalid address cases
    @Test
    void testInvalidAddress_Null() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234567890", null));
    }

    @Test
    void testInvalidAddress_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234567890", "1234567891011121314151617181920212223"));
    }

    // Test updating fields with errors
    @Test
    void testUpdateFirstName_TooLong() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("123456789101112"));
    }

    @Test
    void testUpdateLastName_TooLong() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("123456789101112"));
    }

    @Test
    void testUpdatePhone_InvalidFormat() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("abcdef123456"));
    }

    @Test
    void testUpdateAddress_TooLong() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("This address is way too long for the field."));
    }
}
