CS-320: Software Testing, Automation, and QA
Jason Carignan
4/21/2025
Portfolio Reflection
In this course, I learned a lot about how to ensure that my code is both functional and secure by using unit testing as a regular part of the development process. Through building out services like the ContactService, I saw firsthand how writing automated JUnit tests can catch bugs early and give me more confidence in the quality of my code. I made sure to include both positive and negative test cases to verify proper behavior and exception handling. I also learned the importance of validating inputs and ensuring that classes behave reliably when given bad data, which helps protect against errors and vulnerabilities.

Interpreting user needs was another key part of the course. The project milestones provided clear requirements that simulated real-world specifications, and I learned how to translate those into working code and tests. For example, when the project required that contact IDs be no longer than 10 characters and non-null, I made sure my constructors enforced that and wrote tests to confirm it. Paying attention to these requirements helped ensure the program met the user's expectations and caught edge cases that could’ve been overlooked.

When it came to designing the software, I took a modular approach by keeping each class focused on a single responsibility (like storing contact data or managing a list of contacts). I also made sure that methods were small, readable, and easy to test. Through this experience, I’ve developed a better sense of how to build programs that are clean, testable, and aligned with user needs—skills I know I’ll continue to build on in future projects.
