# Jason Carignan 
# 10/8/2025

# Updated to include Project One Changes including Update and Delete functionality - 10/1/2025
# Updated to include Module Six Changes 10/8/2025
# No changes needed here for Project Two 10/16/2025

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    #def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
       # USER = 'aacuser' 
       # PASS = 'SNHU1234' 
       # HOST = 'localhost' 
       # PORT = 27017 
       # DB = 'aac' 
       # COL = 'animals' 
        # 
        # Initialize Connection 
        # 
       # self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
       # self.database = self.client['%s' % (DB)] 
       # self.collection = self.database['%s' % (COL)] 
        
    #JC 10/3/2025 - Had to update the initializing here to accept user and pass from input. Rewrote the connection string to account for variable changes.
    def __init__(self, USER='aacuser', PASS='SNHU1234'): 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
   
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}') 
        self.database = self.client[DB] 
        self.collection = self.database[COL]    


    # Create a method to return the next available record number for use in the create method
    def next_available_record(self) -> int:
        last = self.collection.find({}, {"rec_num": 1}).sort("rec_num", -1).limit(1) 
        doc = next(last, None) 
        return (doc or {}).get("rec_num", 0) + 1
    
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            data["rec_num"] = self.next_available_record()
            self.database.animals.insert_one(data)  # data should be dictionary 
            return True
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            result = list(self.database.animals.find(query))
            return result
        else:
            return []

    # Update method to implement the U in CRUD
    def update(self, query, new_values):
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print(f"Error updating documents: {e}")
                return 0
        else:
            raise Exception("Query and new_values must be provided")

    # Delete method to implement the D in CRUD
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting documents: {e}")
                return 0
        else:
            raise Exception("Query must be provided")
