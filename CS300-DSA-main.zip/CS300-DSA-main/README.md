# CS300-DSA
CS-300-11649-M01 DSA: Analysis and Design 2025
Jason Carignan - 2/24/2025

What was the problem you were solving in the projects for this course?

The goal of this course was to explore different data structures and analyze their impact on efficiency and memory usage. We worked with Vectors, Hash Tables, and Binary Search Trees, each project focusing on how a specific structure handles tasks such as storing, retrieving, and sorting data efficiently. The key challenge was selecting the best structure based on runtime complexity and scalability, ensuring that operations like searching and sorting were optimized.

How did you approach the problem? Consider why data structures are important to understand.

I approached the problem by first analyzing the requirements and expected data operations, then selecting the most appropriate data structure based on efficiency and ease of implementation. For my project, I chose Hash Tables due to their efficiency in searching a catalog. Since hash tables don’t maintain order, I sorted the course IDs separately to ensure an alphanumeric course list.

How did you overcome any roadblocks you encountered while going through the activities or project?

I encountered a few roadblocks during the course, most of which required slow and methodical testing to identify the source of the issue. I handled case-insensitive lookups by converting user input to uppercase and resolved CSV parsing issues by dynamically reading multiple prerequisites. Since hash tables don’t maintain order, I extracted, sorted, and printed course IDs separately to ensure correct output.

How has your work on this project expanded your approach to designing software and developing programs?

This project reinforced the importance of choosing the right data structure based on efficiency rather than familiarity. It also highlighted the importance of planning before coding, ensuring the best implementation strategy is in place before writing code. While trial-and-error coding might work, a well-structured approach with strong pseudocode and planning leads to more efficient and user-friendly programs.

How has your work on this project evolved the way you write programs that are maintainable, readable, and adaptable?

This project helped reinforce good coding habits while making me rethink some of my less effective practices. In the past, I often jumped into writing code without a solid plan, which led to programs that worked but weren’t always the most efficient. For larger projects, laying out a structured plan and ensuring optimized performance will be crucial for maintainability and scalability.
