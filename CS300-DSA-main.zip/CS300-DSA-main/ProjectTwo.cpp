//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Jason Carignan
// Version     : 1.0
// Date        : 2/20/2025
// Description : CS 300 Module Seven Project Two
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>

using namespace std;

//============================================================================
// Define the Course structure
//============================================================================
struct Course {
    string courseId;              // KeyID - Example: CSCI100
    string courseTitle;          
    vector<string> prerequisites; // List of prerequisite courses put into vector

    Course() = default;
};

//============================================================================
// Define the Hash Table class
//============================================================================
class HashTable {
private:
    unordered_map<string, Course> courses;       // Hash table to store courses using courseId as the key

public:
    void LoadData(const string& filename);      // Load course data from a CSV file
    void PrintAllCourses();                     // Print all courses in sorted order
    void PrintCourse(const string& courseId);   // Print details for a specific course
};

/**
 * Load course data from a CSV file into the hash table.
 */
void HashTable::LoadData(const string& filename) {
    ifstream file(filename); // Open the CSV file
    if (!file) {
        cerr << "Error: Unable to open file " << filename << endl; // Display error if file cannot be opened
        return;
    }

    string line;
    while (getline(file, line)) { // Read each line from the file
        stringstream ss(line);
        Course course;
        string prereq;

        // Read courseId and title from the CSV line
        getline(ss, course.courseId, ',');
        getline(ss, course.courseTitle, ',');

        // Read and store any prerequisite courses
        while (getline(ss, prereq, ',')) {
            course.prerequisites.push_back(prereq);
        }

        // Insert the course into the hash table using courseId as the key
        courses[course.courseId] = course;
    }

    file.close(); // Close the file after reading all data
    cout << "Courses loaded successfully!" << endl;
}

/**
 * Print all courses in alphanumeric order.
 */
void HashTable::PrintAllCourses() {
    if (courses.empty()) { // Check if courses are loaded
        cout << "No courses available. Load data first." << endl;
        return;
    }

    cout << "Here is a sample schedule:" << endl;

    vector<string> courseIds; // Create a vector to store courseIds

    // Store courseIds in the vector
    for (const auto& pair : courses) {
        courseIds.push_back(pair.first);
    }

    // Sort courseIds alphabetically
    sort(courseIds.begin(), courseIds.end());

    // Print courses in sorted order
    for (const auto& courseId : courseIds) {
        cout << courseId << ", " << courses[courseId].courseTitle << endl;
    }
}

/**
 * Print details for a specific course.
 */
void HashTable::PrintCourse(const string& courseId) {
    // Convert courseId input to uppercase for case-insensitive search
    string uppercourseId = courseId;
    transform(uppercourseId.begin(), uppercourseId.end(), uppercourseId.begin(), ::toupper);

    if (courses.find(uppercourseId) != courses.end()) { // Check if course exists
        Course course = courses[uppercourseId]; // Retrieve course details
        cout << course.courseId << ", " << course.courseTitle << endl;

        // Check if the course has prerequisites
        if (!course.prerequisites.empty()) {
            cout << "Prerequisites: ";
            for (size_t i = 0; i < course.prerequisites.size(); ++i) {
                cout << course.prerequisites[i];
                if (i < course.prerequisites.size() - 1) {
                    cout << ", "; // Add a comma between prerequisites
                }
            }
            cout << endl;
        }
    }
    else {
        cout << "Course not found." << endl; // Display message if course is not found
    }
}

//============================================================================
// Main Function
//============================================================================
int main() {
    HashTable courseTable; // Create an instance of HashTable
    string filename = "CS 300 ABCU_Advising_Program_Input.csv"; // File Input Name - Change this if you want to use another file.
    int choice = 0; // Variable to store user input

    cout << "Welcome to the course planner." << endl;

    // Loop until the user selects option 9 to exit
    while (choice != 9) {
        // Display menu options
        cout << "\n1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";
        cin >> choice; // Get user input

        switch (choice) {
        case 1:
            courseTable.LoadData(filename); // Load course data from CSV file
            break;
        case 2:
            courseTable.PrintAllCourses(); // Print all courses in sorted order
            break;
        case 3: {
            string courseId;
            cout << "What course do you want to know about? ";
            cin >> courseId; // Get courseId from user
            courseTable.PrintCourse(courseId); // Print course details
            break;
        }
        case 9:
            cout << "Thank you for using the course planner!" << endl; // Exit message
            break;
        default:
            cout << choice << " is not a valid option." << endl; // Display error for invalid choices
        }
    }

    return 0; // End program
}
