# Contact Management Application

A Simple Python-based contact management system originally developed in Java for
CS 320 - Software Testing. It has been enhanced as part of my Capstone project for CS 499, covering software engineering portfolio artifact.

---

## Setup Instructions

1. Clone or download the repository
2. Install dependencies: Open terminal in Pycharm and type "pip install -r requirements.txt"
4. Run the tests: Right-click the tests folder and select "Run Python tests in test"
5. Start the web app: Right click app.py and select "Run app" or using the terminal type "python -m contact_app.app"
6. Open your internet browser to: http://127.0.0.1:5000

