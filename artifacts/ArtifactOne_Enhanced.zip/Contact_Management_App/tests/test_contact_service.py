"""
Unit tests for the Contact domain model and ContactService.

These tests verify that:
- Validation rules are enforced
- Business rules are respected
- Invalid operations raise appropriate exceptions
"""

import pytest
from contact_app.contact_service import ContactService
from contact_app.exceptions import DuplicateContactError, ContactNotFoundError


def test_service_add_and_get_contact():
    svc = ContactService()
    svc.add_contact("ID1", "TestFirst", "TestLast", "1234567890", "123 Test St")

    c = svc.get_contact("ID1")
    assert c.contact_id == "ID1"
    assert c.first_name == "TestFirst"
    assert c.last_name == "TestLast"
    assert c.phone == "1234567890"
    assert c.address == "123 Test St"


def test_service_duplicate_id_raises():
    svc = ContactService()
    svc.add_contact("ID1", "TestFirst", "TestLast", "1234567890", "123 Test St")

    with pytest.raises(DuplicateContactError):
        svc.add_contact("ID1", "OtherFirst", "OtherLast", "0987654321", "456 Other St")


def test_service_delete_contact():
    svc = ContactService()
    svc.add_contact("ID1", "TestFirst", "TestLast", "1234567890", "123 Test St")

    svc.delete_contact("ID1")

    with pytest.raises(ContactNotFoundError):
        svc.get_contact("ID1")


def test_service_updates_enforce_validation():
    svc = ContactService()
    svc.add_contact("ID1", "TestFirst", "TestLast", "1234567890", "123 Test St")

    # Invalid first name (too long)
    with pytest.raises(ValueError):
        svc.update_first_name("ID1", "ABCDEFGHIJK")

    # Invalid phone (not 10 digits)
    with pytest.raises(ValueError):
        svc.update_phone("ID1", "123")

    # Invalid address (too long)
    with pytest.raises(ValueError):
        svc.update_address("ID1", "A" * 31)

    # Valid update should work
    svc.update_last_name("ID1", "NewLast")
    assert svc.get_contact("ID1").last_name == "NewLast"
