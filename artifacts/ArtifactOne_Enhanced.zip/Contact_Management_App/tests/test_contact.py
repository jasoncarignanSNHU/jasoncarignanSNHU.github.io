"""
Unit tests for the Contact domain model and ContactService.

These tests verify that:
- Validation rules are enforced
- Business rules are respected
- Invalid operations raise appropriate exceptions
"""

import pytest
from contact_app.contact import Contact


def test_contact_valid_creation():
    c = Contact(
        contact_id="ID123",
        first_name="TestFirst",
        last_name="TestLast",
        phone="1234567890",
        address="123 Test St",
    )
    assert c.contact_id == "ID123"
    assert c.first_name == "TestFirst"
    assert c.last_name == "TestLast"
    assert c.phone == "1234567890"
    assert c.address == "123 Test St"


@pytest.mark.parametrize("bad_id", [None, "12345678901"])
def test_contact_invalid_id(bad_id):
    with pytest.raises(ValueError):
        Contact(
            contact_id=bad_id,
            first_name="TestFirst",
            last_name="TestLast",
            phone="1234567890",
            address="123 Test St",
        )


@pytest.mark.parametrize("bad_first", [None, "ABCDEFGHIJK"])
def test_contact_invalid_first_name(bad_first):
    with pytest.raises(ValueError):
        Contact(
            contact_id="ID123",
            first_name=bad_first,
            last_name="TestLast",
            phone="1234567890",
            address="123 Test St",
        )


@pytest.mark.parametrize("bad_last", [None, "ABCDEFGHIJK"])
def test_contact_invalid_last_name(bad_last):
    with pytest.raises(ValueError):
        Contact(
            contact_id="ID123",
            first_name="TestFirst",
            last_name=bad_last,
            phone="1234567890",
            address="123 Test St",
        )


@pytest.mark.parametrize("bad_phone", [None, "123", "abcdefghij", "12345678901"])
def test_contact_invalid_phone(bad_phone):
    with pytest.raises(ValueError):
        Contact(
            contact_id="ID123",
            first_name="TestFirst",
            last_name="TestLast",
            phone=bad_phone,
            address="123 Test St",
        )


@pytest.mark.parametrize("bad_address", [None, "A" * 31])
def test_contact_invalid_address(bad_address):
    with pytest.raises(ValueError):
        Contact(
            contact_id="ID123",
            first_name="TestFirst",
            last_name="TestLast",
            phone="1234567890",
            address=bad_address,
        )
