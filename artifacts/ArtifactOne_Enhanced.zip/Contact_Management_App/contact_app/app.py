"""
app.py

Flask web interface for the Contact Management application.
Provides routes for creating, viewing, and deleting contacts.

Jason Carignan
CS 499 – Computer Science Capstone
Professor Satish Penmatsa
1/21/2026
"""

from __future__ import annotations
from flask import Flask, render_template, request, redirect, url_for, flash
from contact_app.contact_service import ContactService
from contact_app.exceptions import DuplicateContactError, InvalidContactError, ContactNotFoundError


def create_app() -> Flask:
    app = Flask(__name__)
    app.secret_key = "dev-secret-key"  # fine for local dev; change later

    service = ContactService()

    @app.route("/", methods=["GET"])
    def index():
        """Render the main page with all current contacts."""
        contacts = service.get_all_contacts()
        return render_template("index.html", contacts=contacts)

    @app.route("/add", methods=["POST"])
    def add_contact():
        """Handle form submission to add a new contact."""
        try:
            contact_id = request.form.get("contact_id", "").strip()
            first_name = request.form.get("first_name", "").strip()
            last_name = request.form.get("last_name", "").strip()
            phone = request.form.get("phone", "").strip()
            address = request.form.get("address", "").strip()

            service.add_contact(contact_id, first_name, last_name, phone, address)
            flash(f"Contact {contact_id} added.", "success")

        except DuplicateContactError as e:
            flash(str(e), "error")

        # If your Contact validation raises ValueError (as written), this catches it.
        except ValueError as e:
            flash(str(e), "error")

        # If you still have an InvalidContactError class elsewhere and decide to raise it,
        # this keeps compatibility.
        except InvalidContactError as e:
            flash(str(e), "error")

        return redirect(url_for("index"))

    @app.route("/delete/<contact_id>", methods=["POST"])
    def delete_contact(contact_id: str):
        """Delete a contact by ID and redirect back to index."""
        try:
            service.delete_contact(contact_id)
            flash(f"Contact {contact_id} deleted.", "success")
        except ContactNotFoundError as e:
            flash(str(e), "error")

        return redirect(url_for("index"))

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
