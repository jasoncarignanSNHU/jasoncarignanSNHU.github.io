"""
contact_service.py

Provides the service layer for managing Contact objects.
Handles business rules such as uniqueness, retrieval, updates,
and deletion of contacts.

Jason Carignan
CS 499 – Computer Science Capstone
Professor Satish Penmatsa
1/21/2026
"""

from __future__ import annotations
from typing import Dict, List
from .contact import Contact
from .exceptions import DuplicateContactError, ContactNotFoundError


class ContactService:
    """
    Acts as the application service layer.

    Responsibilities:
    - Stores contacts in memory
    - Enforces uniqueness rules
    - Delegates validation to the Contact model
    - Provides safe CRUD operations
    """

    def __init__(self) -> None:
        """Initialize the service with an empty contact store."""
        self._contacts: Dict[str, Contact] = {}

    def get_all_contacts(self) -> List[Contact]:
        return list(self._contacts.values())

    def add_contact(self, contact_id: str, first_name: str, last_name: str, phone: str, address: str) -> None:
        """
        Add a new contact to the system.

        Validation is delegated to the Contact class.
        Raises DuplicateContactError if the ID already exists.
        """
        contact = Contact(
            contact_id=contact_id,
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            address=address,
        )

        if contact.contact_id in self._contacts:
            raise DuplicateContactError("Contact ID already exists.")

        self._contacts[contact.contact_id] = contact

    def get_contact(self, contact_id: str) -> Contact:
        """Retrieve a contact by ID or raise ContactNotFoundError."""
        if contact_id not in self._contacts:
            raise ContactNotFoundError("Contact not found.")
        return self._contacts[contact_id]

    def delete_contact(self, contact_id: str) -> None:
        """Remove a contact from the system by ID."""
        if contact_id not in self._contacts:
            raise ContactNotFoundError("Contact not found.")
        del self._contacts[contact_id]

    # Updates use Contact property setters so validation happens here too
    def update_first_name(self, contact_id: str, first_name: str) -> None:
        """Update the first name of an existing contact."""
        contact = self.get_contact(contact_id)
        contact.first_name = first_name

    def update_last_name(self, contact_id: str, last_name: str) -> None:
        """Update the last name of an existing contact."""
        contact = self.get_contact(contact_id)
        contact.last_name = last_name

    def update_phone(self, contact_id: str, phone: str) -> None:
        """Update the phone number of an existing contact."""
        contact = self.get_contact(contact_id)
        contact.phone = phone

    def update_address(self, contact_id: str, address: str) -> None:
        """Update the address of an existing contact."""
        contact = self.get_contact(contact_id)
        contact.address = address
