"""
contact.py

Defines the Contact domain object for the Contact Management application.
This class is responsible for enforcing all validation rules for contact data
and ensuring that invalid state cannot be created.

Jason Carignan
CS 499 – Computer Science Capstone
Professor Satish Penmatsa
1/21/2026
"""

from __future__ import annotations

class Contact:
    """
    Represents a single contact in the system.

    This class acts as the domain model and is responsible for:
    - Validating all input fields
    - Enforcing immutability for contact_id
    - Preventing invalid state at creation or update time
    """

    def __init__(self, contact_id: str, first_name: str, last_name: str, phone: str, address: str) -> None:
        """
        Initialize a Contact object with validated fields.

        All validation rules are enforced here so that any Contact instance
        created is guaranteed to be in a valid state.
        """

        # Validate ID once and keep it immutable
        self._validate_contact_id(contact_id)
        self._contact_id = contact_id

        # Use property setters so validation is consistent
        self.first_name = first_name
        self.last_name = last_name
        self.phone = phone
        self.address = address

    @property
    def contact_id(self) -> str:
        return self._contact_id

    @property
    def first_name(self) -> str:
        return self._first_name

    @first_name.setter
    def first_name(self, value: str) -> None:
        if value is None or len(value) > 10:
            raise ValueError("First name must not be null and must be 10 characters or fewer.")
        self._first_name = value

    @property
    def last_name(self) -> str:
        return self._last_name

    @last_name.setter
    def last_name(self, value: str) -> None:
        if value is None or len(value) > 10:
            raise ValueError("Last name must not be null and must be 10 characters or fewer.")
        self._last_name = value

    @property
    def phone(self) -> str:
        return self._phone

    @phone.setter
    def phone(self, value: str) -> None:
        if value is None or len(value) != 10 or not value.isdigit():
            raise ValueError("Phone number must be exactly 10 digits.")
        self._phone = value

    @property
    def address(self) -> str:
        return self._address

    @address.setter
    def address(self, value: str) -> None:
        if value is None or len(value) > 30:
            raise ValueError("Address must not be null and must be 30 characters or fewer.")
        self._address = value

    @staticmethod
    def _validate_contact_id(value: str) -> None:
        if value is None or len(value) > 10:
            raise ValueError("Contact ID must not be null and must be 10 characters or fewer.")
