class InvalidContactError(ValueError):
    """Raised when contact fields fail validation."""

class DuplicateContactError(ValueError):
    """Raised when attempting to add a contact with an existing contact_id."""

class ContactNotFoundError(KeyError):
    """Raised when attempting to update or delete a contact that does not exist."""
